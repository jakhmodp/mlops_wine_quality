

def test_generic():
    a = 2
    b = 2
    assert a == b

def another_test():
    assert 1 == 2
